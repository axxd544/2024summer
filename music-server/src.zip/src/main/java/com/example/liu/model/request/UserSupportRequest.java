package com.example.liu.model.request;

import lombok.Data;

/**
 * @Author 祝英台炸油条
 * @Time : 2022/6/11 16:08
 **/
@Data
public class UserSupportRequest {
    Integer id;
    Integer commentId;
    Integer userId;
}
