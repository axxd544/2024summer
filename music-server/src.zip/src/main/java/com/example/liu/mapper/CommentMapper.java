package com.example.liu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liu.model.domain.Comment;
import org.springframework.stereotype.Repository;

@Repository
public interface CommentMapper extends BaseMapper<Comment> {

}
