package com.example.liu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liu.model.domain.SongListConsumerDeleted;

public interface SongListConsumerDeletedMapper extends BaseMapper<SongListConsumerDeleted> {
}
