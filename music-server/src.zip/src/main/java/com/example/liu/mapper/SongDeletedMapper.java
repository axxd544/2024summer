package com.example.liu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liu.model.domain.SongDeleted;

public interface SongDeletedMapper extends BaseMapper<SongDeleted> {
}
