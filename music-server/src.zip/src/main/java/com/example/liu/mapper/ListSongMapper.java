package com.example.liu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liu.model.domain.ListSong;
import org.springframework.stereotype.Repository;

@Repository
public interface ListSongMapper extends BaseMapper<ListSong> {

}
