package com.example.liu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.liu.model.domain.Follow;
import org.springframework.stereotype.Repository;

@Repository
public interface FollowMapper extends BaseMapper<Follow> {
}
