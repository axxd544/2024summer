export const MUSICNAME = 'i-music 后台管理'
